function plotsines(x,y,z)
%Plot sinusoid functions on formatted plot
%
%plotsines takes in the following inputs
%   x: x values
%   y: sin(x)
%   z: (optional) cos(x)

%% set up plot
figure('Position',[150,150,800,400]);

%% plot sinudoids
plot(x,y,'Color','k','LineStyle','--');
if nargin==3 && ~isempty(z) %if desired, plot second sinusoid
    hold on
    plot(x,z,'Color','r','LineStyle',':');
    hold off
end

%% format plot after graphing to avoid messing up formatting
set(gca,'XLim',[0,2*pi],'YLim',[-1,1]);
xlabel('Angle (rad)');
ylabel('Amplitude');
title('Sinusoid Plot','FontSize',24);
legend('Sine','Cosine');

end