function [sequence] = fibonacci_sequence(n)
% return n values of the Fibonacci sequence

sequence = zeros(1,n);
h = waitbar(0,'Calculating...');
for i=1:n
    if i==1 || i==2 % first two values are 1
        sequence(i) = 1;
    else
        % calculate nth value
        sequence(i) = sequence(i-2)+sequence(i-1);
    end
    waitbar(i/n,['Calculating value # ',num2str(i)]);
end

end