data =  xlsread('ds1_Groundtruth');

x = data(:,2);
y = data(:,3);
r = data(:,4);

clearvars data

L = length(x);
l = round(L/100);

h_fig = figure;
h_obj = plot(x(1:l),y(1:l));

for i=2:100
    pause(0.05);
    xdata = get(h_obj,'xdata');
    ydata = get(h_obj,'ydata');
    try
        xdata = [xdata,x((l*(i-1)-1):(l*i))'];
        ydata = [ydata,y((l*(i-1)-1):(l*i))'];
    catch
        xdata = x;
        ydata = y;
    end
    set(h_obj,'xdata',xdata);
    set(h_obj,'ydata',ydata);
    
    drawnow;
end