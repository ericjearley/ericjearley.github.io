function [saveName, dirNames] = preventOverwrite(desiredName,ext,dirNames)

%Prevent overwriting of files by generating unique file name
%   [saveName,dirNames] = preventOverwrite(desiredName,ext)
%   [saveName,dirNames] = preventOverwrite(...,...,dirNames)
%
%Compares desired name and file extension to existing files in
%   a directory
%   If a match exists, desired name will be appended with (#) until
%   a match no longer occurs
%
%preventOverwrite takes the following inputs:
%   desiredName: String of desired file name
%   ext: File extension (.mat, .fig, etc.)
%   dirNames: (optional) Cell array of names existing in desired directory
%       If empty, variable is filled with names in current directory
%
%preventOverwrite returns the following outputs:
%   saveName: Unique file name
%   dirNames: Cell array of names existing in desired directory
%
%Written by Eric Earley, 2013
%   RIC, Center for Bionic Medicine

%% populate file list from current directory, if necessary
if nargin < 3 || isempty(dirNames) %if no directory names passed in
    dircontent = dir; %pull contents of current directory
    dircontent = dircontent(~[dircontent.isdir]); %remove directories
    dirNames = {dircontent.name}; %save file names
    clearvars dircontent
end

%% generate a unique file name
saveName = [desiredName,ext];
m=1; %initialize file appendix
while any(strcmp(saveName,dirNames)); %if match exists
    m=m+1; %incriment file appendix
    saveName = [desiredName '(' int2str(m) ')' ext];
end
saveName = strrep(saveName,ext,''); %remove extension

end