function [C] = sampleCovar(x,mu)
%Sample Covariance
%   Calculate the covariance matrix with an optional population mean
%   [C] = manualCovar(x)
%   [C] = manualCovar(x,mu)
%
%manualCovar takes the following inputs:
%   x: [TxN] array of data points
%       T = # observations
%       N = # variables
%   mu: (optional) [Tx1] vector of means
%       If empty, calculates mean from data and normalizes by T-1
%       Otherwise, covariance is normalized by T
%Written by Eric Earley, 2013
%   RIC, Center for Bionic Medicine

T = size(x,1);

if nargin < 2 || isempty(mu)
    mu = mean(x); %calculate data mean
    norm = T-1; %unbiased estimator for unknown population means
else
    norm = T; %unbiased estimator  for known population means
end

xn = bsxfun(@minus,x,mu); %subtract column averages from columns

C = (xn' * xn) / norm; %calculate covariance

end