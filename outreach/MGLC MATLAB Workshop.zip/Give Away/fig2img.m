function [] = fig2img(ext)

%Allows user to convert existing .fig files into image files
%   fig2img()
%   fig2img(ext)
%
%fig2img takes the following inputs:
%   ext: (optional) image file extension (.png, .jpg, etc.)
%       Default: .png
%
%Written by Eric Earley, 2013
%   RIC, Center for Bionic Medicine

if nargin < 1 || isempty(ext)
    ext = '.png';
end

if ext(1) ~= '.' %ensure dot at end of extension
    ext = ['.' ext];
end

[figs,path] = uigetfile('*.fig','Select MATLAB figures to convert.','MultiSelect','on');
old = cd(path);
%set(h,'PaperPositionMode','auto','InvertHardCopy','off','Color','w');

if ~iscell(figs) %one selection
    open(figs);
    savename = figs(1:end-4); %remove .fig
    savename = [savename ext]; %add extension
    set(gcf,'PaperPositionMode','auto','InvertHardCopy','off','Color','w');
    saveas(gcf,savename);
    close(gcf);
else %multiple selections
    L = length(figs);
    for i=1:L
        open(figs{i});
        savename = figs{i}(1:end-4); %remove .fig
        savename = [savename ext]; %#ok<AGROW> %add extension
        set(gcf,'PaperPositionMode','auto','InvertHardCopy','off','Color','w');
        saveas(gcf,savename);
        close(gcf);
    end
end

cd(old);